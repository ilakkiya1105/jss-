// function myfunc(){

// document.getElementById('hcontent').innerHTML='welcome guys'

// }

function my(){
    document.getElementById('mem').innerHTML="i have changed the content";
            }
    
            function my1(){
    document.getElementById('did').style.color="yellow";
            }
    
            function my2(){
                document.getElementById('image') .src = " c:/Users/user/Downloads/pexels-photo-931177.jpeg";
            }