const func =() =>{

    const username =document.getElementById("usn").value;
    const pass =document.getElementById("psw").value;
    alert(`hi, ${username}`)


}




document.getElementById("btnid").addEventListener("click",func)

let us = document.getElementById('lemon')
let zip =us.value
console.log(zip)