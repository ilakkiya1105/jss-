// if(new Date().getTime()<12){
//     document.getElementById('demo').innerHTML="be happy"
// }
// var day = new Date();

// var zip = day.getDate();
// console.log(zip)

// Get input from the user
// Convert the input to a number (assuming the input is a string)
// let mark=prompt("enter your value:");
// mark=parseInt(mark)

let mark1=parseInt(prompt("enter the marks"))
if(mark1<=100){
    console.log("pass")
}
else if(mark1>=105){
    console.log("great")
}
else{
console.log("invalid")
}