function myfunc(){
    document.getElementById('demo').innerHTML="good morning";
  }

  function myFun(){

    document.getElementById('demo1').style.color="yellow";

  }

  function myImage(){
    document.getElementById('image').src="c:/Users/user/Downloads/pexels-photo-931177.jpeg"
  }

  function myDid(){

    document.getElementById('did').style.display = "none";
  }